package com.example.callculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void toBinary(View view) {
        Intent i = new Intent(MainActivity.this, Binary.class);
        startActivity(i);
    }

    public void toOctal(View view) {
        Intent i = new Intent(MainActivity.this, Octal.class);
        startActivity(i);
    }

    public void toTriginometric(View view){
        Intent i = new Intent(MainActivity.this, Triginometric.class);
        startActivity(i);
    }
}