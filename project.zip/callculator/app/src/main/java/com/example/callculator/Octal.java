package com.example.callculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Octal extends AppCompatActivity {

    public TextView thisNum;
    public TextView answer;
    public TextView otherNum;
    public String operation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        thisNum = findViewById(R.id.numberThis);
        answer = findViewById(R.id.answer);
        otherNum = findViewById(R.id.numberOne);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_octal);
    }

    public void plus(View view) {
        otherNum.setText("");
        otherNum.setText((String) thisNum.getText());
        thisNum.setText("");
        operation = "+";
    }

    public void minus(View view) {
        otherNum.setText("");
        otherNum.setText((String) thisNum.getText());
        thisNum.setText("");
        operation = "-";
    }

    public void getResult(View view) {
        Integer num1 = Integer.parseInt((String) otherNum.getText(), 8);
        Integer num2 = Integer.parseInt((String) thisNum.getText(), 8);
        answer.setText("");
        answer.setText(Integer.toOctalString(num1 + num2));

    }

    public void toZero(View view) {
        otherNum.setText("");
        thisNum.setText("");
        answer.setText("");
    }

    public void goBack(View view) {
        Intent i = new Intent(Octal.this, MainActivity.class);
        startActivity(i);
    }

    public void addOne(View view) {
        thisNum.setText("1");
    }

    public void addZero(View view) {
        thisNum.setText("0");
    }

    public void addTwo(View view) {
        thisNum.setText("2");
    }

    public void addThree(View view) {
        thisNum.setText("3");
    }

    public void addFour(View view) {
        thisNum.setText("4");
    }

    public void addFive(View view) {
        thisNum.setText("5");
    }

    public void addSix(View view) {
        thisNum.setText("6");
    }

    public void addSeven(View view) {
        thisNum.setText("7");
    }
}
