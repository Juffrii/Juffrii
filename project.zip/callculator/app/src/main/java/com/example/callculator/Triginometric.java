package com.example.callculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Triginometric extends AppCompatActivity {

    public TextView num;
    public TextView answer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_triginometric);
        num = findViewById(R.id.toWork);
        answer = findViewById(R.id.answer);
    }

    public void addOne(View view) {
        num.setText("1");
    }

    public void addTwo(View view) {
        num.setText("2");
    }

    public void addThree(View view) {
        num.setText("3");
    }

    public void addFour(View view) {
        num.setText("4");
    }

    public void addFive(View view) {
        num.setText("5");
    }

    public void addSix(View view) {
        num.setText("6");
    }

    public void addSeven(View view) {
        num.setText("7");
    }

    public void addEight(View view) {
        num.setText("8");
    }

    public void addNine(View view) {
        num.setText("9");
    }

    public void addZero(View view) {
        num.setText("0");
    }

    public void addPoint(View view) {
        num.setText(",");
    }

    public void setToZero(View view) {
        num.setText("");
        answer.setText("");
    }

    public void sin(View view) {
        answer.setText("");
        double nm;
        nm = Double.parseDouble((String) num.getText());
        answer.setText((int) Math.sin(nm));
    }

    public void cos(View view) {
        answer.setText("");
        double nm;
        nm = Double.parseDouble((String) num.getText());
        answer.setText((int) Math.cos(nm));
    }

    public void tg(View view) {
        answer.setText("");
        double nm;
        nm = Double.parseDouble((String) num.getText());
        answer.setText((int) Math.tan(nm));
    }

    public void ctg(View view) {
        answer.setText("");
        double nm;
        nm = Double.parseDouble((String) num.getText());
        answer.setText((int) Math.tanh(nm));
    }
}